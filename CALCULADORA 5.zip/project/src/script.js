// Este archivo se mantiene por compatibilidad con la estructura original
// pero la funcionalidad ha sido migrada a React en App.tsx

document.addEventListener('DOMContentLoaded', function() {
  // Verificar si estamos en un entorno no-React
  if (document.getElementById('calcularTasaBtn')) {
    document.getElementById('calcularTasaBtn').addEventListener('click', calcularTasa);
    document.getElementById('calcularMontoBtn').addEventListener('click', calcularMontoRecibir);
  }
});

// Función para formatear números con separador de miles
function formatearNumero(numero) {
  return numero.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function calcularTasa() {
  const precioCompra = parseFloat(document.getElementById('precioCompra').value);
  const precioVenta = parseFloat(document.getElementById('precioVenta').value);
  const porcentajeGanancia = parseFloat(document.getElementById('porcentajeGanancia').value) / 100;
  const origen = document.getElementById('origen').value;
  const destino = document.getElementById('destino').value;
  const tasaClienteInput = document.getElementById('tasaCliente');

  // Validaciones
  if ([precioCompra, precioVenta, porcentajeGanancia].some(isNaN)) {
    alert('Por favor, ingresa valores numéricos válidos para calcular la tasa.');
    return;
  }

  let tasaCalculada;

  // Reglas especiales para Colombia y Venezuela
  if (origen === 'COLOMBIA' && destino === 'VENEZUELA') {
    tasaCalculada = (precioCompra / precioVenta) * (1 + porcentajeGanancia);
  } else if (destino === 'COLOMBIA' && origen === 'VENEZUELA') {
    tasaCalculada = (precioCompra / precioVenta) * (1 - porcentajeGanancia);
  } else {
    // Regla general para otros países
    tasaCalculada = (precioVenta / precioCompra) * (1 - porcentajeGanancia);
  }

  // Mostrar la tasa calculada
  tasaClienteInput.value = (origen === 'COLOMBIA' || destino === 'COLOMBIA') ? 
                          tasaCalculada.toFixed(6) : 
                          tasaCalculada.toFixed(4);
}

function calcularMontoRecibir() {
  const montoEnviar = parseFloat(document.getElementById('montoEnviar').value);
  const tasaCliente = parseFloat(document.getElementById('tasaCliente').value);
  const montoRecibirInput = document.getElementById('montoRecibir');
  const origen = document.getElementById('origen').value;
  const destino = document.getElementById('destino').value;

  // Validaciones
  if ([montoEnviar, tasaCliente].some(isNaN)) {
    alert('Por favor, calcula primero la tasa y luego ingresa un monto a enviar válido.');
    return;
  }

  // Calcular el monto a recibir según las reglas específicas
  let montoRecibir;
  
  if (origen === 'COLOMBIA' && destino === 'VENEZUELA') {
    // Si origen es Colombia y destino Venezuela, el monto a enviar se divide entre la tasa calculada
    montoRecibir = montoEnviar / tasaCliente;
  } else if (origen === 'VENEZUELA' && destino === 'COLOMBIA') {
    // Si origen es Venezuela y destino Colombia, el monto a enviar se multiplica por la tasa calculada
    montoRecibir = montoEnviar * tasaCliente;
  } else {
    // Para otras combinaciones, se mantiene la multiplicación
    montoRecibir = montoEnviar * tasaCliente;
  }
  
  // Formatear el monto a recibir con separador de miles
  montoRecibirInput.value = formatearNumero(montoRecibir);
}