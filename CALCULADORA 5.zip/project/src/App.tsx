import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import './styles.css';

function App() {
  const [precioCompra, setPrecioCompra] = useState<number | ''>('');
  const [precioVenta, setPrecioVenta] = useState<number | ''>('');
  const [porcentajeGanancia, setPorcentajeGanancia] = useState<number | ''>('');
  const [origen, setOrigen] = useState<string>('COLOMBIA');
  const [destino, setDestino] = useState<string>('VENEZUELA');
  const [montoEnviar, setMontoEnviar] = useState<number | ''>('');
  const [tasaCliente, setTasaCliente] = useState<string>('');
  const [montoRecibir, setMontoRecibir] = useState<string>('');

  // Función para formatear números con separador de miles
  const formatearNumero = (numero: number): string => {
    return numero.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  // Función para calcular la tasa
  const calcularTasa = () => {
    // Validaciones
    if (!precioCompra || !precioVenta || !porcentajeGanancia) {
      alert('Por favor, ingresa valores numéricos válidos para calcular la tasa.');
      return;
    }

    const precioCompraNum = Number(precioCompra);
    const precioVentaNum = Number(precioVenta);
    const porcentajeGananciaNum = Number(porcentajeGanancia) / 100;

    let tasaCalculada;

    // Reglas especiales para Colombia y Venezuela
    if (origen === 'COLOMBIA' && destino === 'VENEZUELA') {
      tasaCalculada = (precioCompraNum / precioVentaNum) * (1 + porcentajeGananciaNum);
    } else if (origen === 'VENEZUELA' && destino === 'COLOMBIA') {
      // Fórmula corregida para Venezuela a Colombia
      const tasaBase = precioVentaNum / precioCompraNum;
      tasaCalculada = tasaBase * (1 - porcentajeGananciaNum);
    } else {
      // Regla general para otros países
      tasaCalculada = (precioVentaNum / precioCompraNum) * (1 - porcentajeGananciaNum);
    }

    // Mostrar la tasa calculada
    setTasaCliente(
      (origen === 'COLOMBIA' || destino === 'COLOMBIA') 
        ? tasaCalculada.toFixed(6) 
        : tasaCalculada.toFixed(4)
    );
  };

  // Función para calcular el monto a recibir
  const calcularMontoRecibir = () => {
    // Validaciones
    if (!montoEnviar || !tasaCliente) {
      alert('Por favor, calcula primero la tasa y luego ingresa un monto a enviar válido.');
      return;
    }

    const montoEnviarNum = Number(montoEnviar);
    const tasaClienteNum = Number(tasaCliente);
    
    // Calcular el monto a recibir según las reglas específicas
    let montoRecibirCalculado;
    
    if (origen === 'COLOMBIA' && destino === 'VENEZUELA') {
      // Si origen es Colombia y destino Venezuela, el monto a enviar se divide entre la tasa calculada
      montoRecibirCalculado = montoEnviarNum / tasaClienteNum;
    } else if (origen === 'VENEZUELA' && destino === 'COLOMBIA') {
      // Si origen es Venezuela y destino Colombia, el monto a enviar se multiplica por la tasa calculada
      montoRecibirCalculado = montoEnviarNum * tasaClienteNum;
    } else {
      // Para otras combinaciones, se mantiene la multiplicación
      montoRecibirCalculado = montoEnviarNum * tasaClienteNum;
    }
    
    // Formatear el monto a recibir con separador de miles
    setMontoRecibir(formatearNumero(montoRecibirCalculado));
  };

  const paises = [
    'COLOMBIA', 'ARGENTINA', 'BRASIL', 'CHILE', 'MEXICO', 'PERU', 'VENEZUELA',
    'EEUU', 'CANADA', 'ESPAÑA', 'PANAMA', 'ECUADOR', 'URUGUAY', 'PARAGUAY',
    'BOLIVIA', 'COSTA_RICA', 'REPUBLICA_DOMINICANA', 'NIGERIA', 'KENIA',
    'INDIA', 'RUSIA', 'UCRANIA', 'REINO_UNIDO', 'ESCOCIA', 'GALES',
    'IRLANDA_NORTE', 'GIBRALTAR'
  ];

  const paisesNombres: Record<string, string> = {
    'COLOMBIA': 'COLOMBIA',
    'ARGENTINA': 'ARGENTINA',
    'BRASIL': 'BRASIL',
    'CHILE': 'CHILE',
    'MEXICO': 'MÉXICO',
    'PERU': 'PERÚ',
    'VENEZUELA': 'VENEZUELA',
    'EEUU': 'ESTADOS UNIDOS',
    'CANADA': 'CANADÁ',
    'ESPAÑA': 'ESPAÑA',
    'PANAMA': 'PANAMÁ',
    'ECUADOR': 'ECUADOR',
    'URUGUAY': 'URUGUAY',
    'PARAGUAY': 'PARAGUAY',
    'BOLIVIA': 'BOLIVIA',
    'COSTA_RICA': 'COSTA RICA',
    'REPUBLICA_DOMINICANA': 'REP. DOMINICANA',
    'NIGERIA': 'NIGERIA',
    'KENIA': 'KENIA',
    'INDIA': 'INDIA',
    'RUSIA': 'RUSIA',
    'UCRANIA': 'UCRANIA',
    'REINO_UNIDO': 'REINO UNIDO',
    'ESCOCIA': 'ESCOCIA',
    'GALES': 'GALES',
    'IRLANDA_NORTE': 'IRLANDA DEL NORTE',
    'GIBRALTAR': 'GIBRALTAR'
  };

  return (
    <div className="container">
      <h1>
        <Calculator className="inline-block mr-2" size={24} />
        Calculadora de Tasa Internacional
      </h1>
      
      {/* Campos para calcular la tasa */}
      <div className="input-container">
        <label htmlFor="precioCompra">Precio de Compra:</label>
        <input 
          type="number" 
          id="precioCompra"
          value={precioCompra}
          onChange={(e) => setPrecioCompra(e.target.value ? Number(e.target.value) : '')}
        />
      </div>
      <div className="input-container">
        <label htmlFor="precioVenta">Precio de Venta:</label>
        <input 
          type="number" 
          id="precioVenta"
          value={precioVenta}
          onChange={(e) => setPrecioVenta(e.target.value ? Number(e.target.value) : '')}
        />
      </div>
      <div className="input-container">
        <label htmlFor="porcentajeGanancia">% Ganancia:</label>
        <input 
          type="number" 
          id="porcentajeGanancia"
          value={porcentajeGanancia}
          onChange={(e) => setPorcentajeGanancia(e.target.value ? Number(e.target.value) : '')}
        />
      </div>
      <div className="input-container">
        <label htmlFor="origen">Origen:</label>
        <select 
          id="origen"
          value={origen}
          onChange={(e) => setOrigen(e.target.value)}
        >
          {paises.map(pais => (
            <option key={pais} value={pais}>{paisesNombres[pais]}</option>
          ))}
        </select>
      </div>
      <div className="input-container">
        <label htmlFor="destino">Destino:</label>
        <select 
          id="destino"
          value={destino}
          onChange={(e) => setDestino(e.target.value)}
        >
          {paises.map(pais => (
            <option key={pais} value={pais}>{paisesNombres[pais]}</option>
          ))}
        </select>
      </div>
      <div className="button-container">
        <button onClick={calcularTasa}>Calcular Tasa</button>
      </div>
      <div className="input-container">
        <label htmlFor="tasaCliente">Tasa Calculada:</label>
        <input 
          type="text" 
          id="tasaCliente" 
          value={tasaCliente}
          readOnly
        />
      </div>

      {/* Campos para simular envío */}
      <div className="input-container">
        <label htmlFor="montoEnviar">Monto a Enviar:</label>
        <input 
          type="number" 
          id="montoEnviar"
          value={montoEnviar}
          onChange={(e) => setMontoEnviar(e.target.value ? Number(e.target.value) : '')}
        />
      </div>
      <div className="button-container">
        <button onClick={calcularMontoRecibir}>Calcular Monto a Recibir</button>
      </div>
      <div className="input-container">
        <label htmlFor="montoRecibir">Monto a Recibir:</label>
        <input 
          type="text" 
          id="montoRecibir" 
          value={montoRecibir}
          readOnly
        />
      </div>
    </div>
  );
}

export default App;